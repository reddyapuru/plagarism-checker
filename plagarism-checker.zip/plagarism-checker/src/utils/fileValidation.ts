const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB in bytes

export function validateFile(file: File): boolean {
  if (!file) {
    alert('Please select a file');
    return false;
  }

  if (!file.type || file.type !== 'application/pdf') {
    alert('Please upload a PDF file');
    return false;
  }

  if (file.size > MAX_FILE_SIZE) {
    alert('File size exceeds 5MB limit');
    return false;
  }

  return true;
}