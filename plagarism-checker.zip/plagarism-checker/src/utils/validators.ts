export class FileValidator {
  private static readonly MAX_SIZE = 5 * 1024 * 1024; // 5MB
  private static readonly ALLOWED_TYPES = ['application/pdf'];

  static validate(file: File): boolean {
    if (!file) {
      this.showError('Please select a file');
      return false;
    }

    if (!this.ALLOWED_TYPES.includes(file.type)) {
      this.showError('Please upload a PDF file');
      return false;
    }

    if (file.size > this.MAX_SIZE) {
      this.showError('File size exceeds 5MB limit');
      return false;
    }

    return true;
  }

  private static showError(message: string): void {
    alert(message); // In production, use a proper toast/notification system
  }
}