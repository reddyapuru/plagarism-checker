import React, { useState } from 'react';
import { BookCheck } from 'lucide-react';
import  FileUpload  from './components/FileUpload';
import { ProgressBar } from './components/ProgressBar';
import { Results } from './components/Results';
import { ApiService, AnalysisResponse } from './services/api';

export default function App() {
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<AnalysisResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    try {
      setIsUploading(true);
      setError(null);
      setProgress(0);

      // Simulate progress while processing
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 10, 90));
      }, 500);

      const response = await ApiService.uploadFile(file);
      
      clearInterval(progressInterval);
      setProgress(100);
      setResults(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <BookCheck className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            PhD Thesis Plagiarism Checker
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Upload your thesis to check for potential plagiarism across multiple academic sources.
            Results are automatically deleted after 1 hour for your privacy.
          </p>
        </div>

        <FileUpload 
          onFileSelect={handleFileSelect}
          isUploading={isUploading}
        />

        {isUploading && (
          <ProgressBar 
            progress={progress}
            status="Analyzing document..."
          />
        )}

        {error && (
          <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {results && (
          <Results
            results={results.results}
            totalSentences={results.totalSentences}
            matchesFound={results.matchesFound}
          />
        )}
      </div>
    </div>
  );
}