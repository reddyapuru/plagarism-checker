import React, { useCallback, useState } from "react";
import { Upload } from "lucide-react";
import { FileValidator } from "../utils/validators";

interface FileUploadProps {
  onFileSelect: (file: File) => Promise<void>;
  isUploading: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, isUploading }) => {
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (FileValidator.validate(file)) {
        onFileSelect(file);
      }
    },
    [onFileSelect]
  );

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file && FileValidator.validate(file)) {
        onFileSelect(file);
      }
    },
    [onFileSelect]
  );

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div
        className={`border-2 border-dashed border-gray-300 rounded-lg p-8 text-center 
          ${isUploading ? "opacity-50 cursor-not-allowed" : "hover:border-blue-500"} 
          transition-colors`}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        <input
          type="file"
          id="fileInput"
          accept=".pdf"
          onChange={handleFileInput}
          disabled={isUploading}
          className="hidden"
        />

        <label
          htmlFor="fileInput"
          className={`space-y-4 ${isUploading ? "cursor-not-allowed" : "cursor-pointer"}`}
        >
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <div className="text-sm text-gray-600">
            <span className="text-blue-600 hover:text-blue-500">Upload a file</span>
            <p>or drag and drop</p>
          </div>
          <p className="text-xs text-gray-500">PDF up to 5MB (max 1000 pages)</p>
        </label>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<any[]>([]);

  const onFileSelect = async (file: File) => {
    setIsUploading(true);
    setError(null); // Reset previous errors

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "An unexpected error occurred");
      }

      const data = await response.json();
      if (data.success) {
        setResults(data.results);
      } else {
        throw new Error("Unexpected response format");
      }
    } catch (error: any) {
      setError(error.message || "An unknown error occurred");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-lg font-semibold mb-4">Upload a PDF File</h2>
      <FileUpload onFileSelect={onFileSelect} isUploading={isUploading} />

      {isUploading && <p className="mt-4 text-blue-600">Uploading file... Please wait.</p>}

      {error && <p className="mt-4 text-red-600">Error: {error}</p>}

      {results.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-semibold">Results</h3>
          <ul className="mt-4 space-y-2">
            {results.map((result, index) => (
              <li key={index} className="p-4 bg-gray-100 rounded-lg">
                <p><strong>Sentence:</strong> {result.sentence}</p>
                <p>
                  <strong>Source:</strong>{" "}
                  <a href={result.source} target="_blank" rel="noopener noreferrer" className="text-blue-500">
                    {result.sourceName}
                  </a>
                </p>
                <p><strong>Similarity:</strong> {result.similarity}%</p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default App;
