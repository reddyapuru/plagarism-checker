import React from 'react';

interface ProgressBarProps {
  progress: number;
  status: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ progress, status }) => (
  <div className="bg-white rounded-lg shadow-sm p-6 mb-4">
    <div className="space-y-2">
      <div className="flex justify-between text-sm font-medium text-gray-900">
        <span>{status}</span>
        <span>{progress}%</span>
      </div>
      <div className="bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-2 bg-blue-600 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  </div>
);