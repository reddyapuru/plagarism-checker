import React from 'react';
import { ExternalLink } from 'lucide-react';
import { PlagiarismResult } from '../services/api';
import { AnalysisService } from '../services/analysis';

interface ResultCardProps {
  result: PlagiarismResult;
}

export const ResultCard: React.FC<ResultCardProps> = ({ result }) => {
  const severity = AnalysisService.calculateSeverity(result.similarity);
  const severityClass = AnalysisService.getSeverityClass(severity);
  const severityText = AnalysisService.getSeverityText(severity);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-4">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-2">
          <span className={`${severityClass} px-3 py-1 rounded-full text-sm font-medium`}>
            {result.similarity}% Match
          </span>
          <span className="text-sm text-gray-500">{severityText}</span>
        </div>
        
        <a
          href={result.source}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
        >
          <ExternalLink className="w-4 h-4 mr-1" />
          View Source
        </a>
      </div>

      <div className="bg-gray-50 p-4 rounded border border-gray-200 mb-4">
        <h4 className="font-medium mb-2">Matched Text:</h4>
        <p className="text-gray-700">{result.sentence}</p>
      </div>

      {result.snippet && (
        <div className="bg-gray-50 p-4 rounded border border-gray-200 mb-4">
          <h4 className="font-medium mb-2">Source Context:</h4>
          <p className="text-gray-700">{result.snippet}</p>
        </div>
      )}

      <div className="text-sm text-gray-500">
        Source: {result.sourceName}
      </div>
    </div>
  );
};