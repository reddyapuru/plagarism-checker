import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { PlagiarismResult } from '../services/api';
import { ResultCard } from './ResultCard';

interface ResultsProps {
  results: PlagiarismResult[];
  totalSentences: number;
  matchesFound: number;
}

export const Results: React.FC<ResultsProps> = ({ 
  results, 
  totalSentences, 
  matchesFound 
}) => {
  if (!results.length) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 text-center">
        <p className="text-gray-600">No plagiarism detected in the analyzed content.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex items-center">
          <AlertTriangle className="w-5 h-5 text-yellow-400 mr-2" />
          <p className="text-sm text-yellow-700">
            Results will be automatically deleted after 1 hour
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-2">Analysis Summary</h2>
        <p className="text-gray-600">
          Analyzed {totalSentences} sentences and found {matchesFound} potential matches.
        </p>
      </div>

      {results.map((result, index) => (
        <ResultCard key={index} result={result} />
      ))}
    </div>
  );
};