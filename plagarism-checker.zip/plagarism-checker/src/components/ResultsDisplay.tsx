import React from 'react';
import { ExternalLink, AlertTriangle } from 'lucide-react';
import { PlagiarismResult } from '../types';

interface ResultsDisplayProps {
  results: PlagiarismResult[];
  isLoading: boolean;
}

export function ResultsDisplay({ results, isLoading }: ResultsDisplayProps) {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!results.length) {
    return null;
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex items-center">
          <AlertTriangle className="w-5 h-5 text-yellow-400 mr-2" />
          <p className="text-sm text-yellow-700">
            Results will be automatically deleted after 1 hour
          </p>
        </div>
      </div>

      {results.map((result, index) => (
        <div key={index} className="bg-white shadow-md rounded-lg p-6">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold text-gray-800">
              Match {index + 1} - {result.similarity}% Similar
            </h3>
            <a
              href={result.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center text-blue-600 hover:text-blue-800"
            >
              <ExternalLink className="w-4 h-4 mr-1" />
              Source
            </a>
          </div>
          
          <div className="mt-4">
            <div className="bg-gray-50 p-4 rounded border border-gray-200">
              <p className="text-gray-700">{result.matchedText}</p>
            </div>
          </div>
          
          <div className="mt-4 text-sm text-gray-500">
            Found in: {result.sourceName}
          </div>
        </div>
      ))}
    </div>
  );
}