export interface PlagiarismResult {
  similarity: number;
  matchedText: string;
  sourceUrl: string;
  sourceName: string;
}

export interface UploadState {
  file: File | null;
  progress: number;
  status: string;
}