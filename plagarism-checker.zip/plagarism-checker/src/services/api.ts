export interface PlagiarismResult {
  sentence: string;
  source: string;
  sourceName: string;
  similarity: number;
  snippet?: string;
}

export interface AnalysisResponse {
  results: PlagiarismResult[];
  totalSentences: number;
  matchesFound: number;
}

export class ApiService {
  private static readonly API_BASE = '/api';

  static async uploadFile(file: File): Promise<AnalysisResponse> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${this.API_BASE}/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Upload failed');
    }

    return response.json();
  }
}