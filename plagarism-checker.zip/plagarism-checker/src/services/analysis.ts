import { PlagiarismResult } from './api';

export class AnalysisService {
  static calculateSeverity(similarity: number): 'high' | 'medium' | 'low' {
    if (similarity > 70) return 'high';
    if (similarity > 40) return 'medium';
    return 'low';
  }

  static getSeverityClass(severity: 'high' | 'medium' | 'low'): string {
    const classes = {
      high: 'bg-red-100 text-red-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    return classes[severity];
  }

  static getSeverityText(severity: 'high' | 'medium' | 'low'): string {
    const texts = {
      high: 'High similarity - potential plagiarism',
      medium: 'Moderate similarity - needs review',
      low: 'Low similarity - likely original'
    };
    return texts[severity];
  }

  static formatResults(results: PlagiarismResult[]): PlagiarismResult[] {
    return results.map(result => ({
      ...result,
      similarity: Math.round(result.similarity * 100)
    }));
  }
}