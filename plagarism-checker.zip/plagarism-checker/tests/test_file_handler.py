import unittest
import os
from werkzeug.datastructures import FileStorage
from app.utils.file_handler import FileHandler
from app.config import Config

class TestFileHandler(unittest.TestCase):
    def setUp(self):
        self.test_file = 'test.pdf'
        
    def test_allowed_file(self):
        self.assertTrue(FileHandler.allowed_file('test.pdf'))
        self.assertFalse(FileHandler.allowed_file('test.txt'))
        
    def test_save_file(self):
        with open(self.test_file, 'wb') as f:
            f.write(b'Test PDF content')
            
        with open(self.test_file, 'rb') as f:
            file = FileStorage(f)
            filepath = FileHandler.save_file(file)
            
        self.assertIsNotNone(filepath)
        self.assertTrue(os.path.exists(filepath))
        
        # Cleanup
        os.remove(filepath)
        os.remove(self.test_file)