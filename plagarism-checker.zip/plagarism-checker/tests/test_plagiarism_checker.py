import unittest
from unittest.mock import patch
from app.utils.plagiarism_checker import PlagiarismChecker

class TestPlagiarismChecker(unittest.TestCase):
    def setUp(self):
        self.checker = PlagiarismChecker()
        
    def test_check_similarity(self):
        text1 = "This is a test"
        text2 = "This is a test"
        similarity = self.checker.check_similarity(text1, text2)
        self.assertEqual(similarity, 1.0)
        
        text2 = "This is different"
        similarity = self.checker.check_similarity(text1, text2)
        self.assertLess(similarity, 1.0)
        
    @patch('requests.get')
    def test_search_content(self, mock_get):
        mock_get.return_value.status_code = 200
        mock_get.return_value.text = '''
            <html>
                <a href="http://example.com">This is a test</a>
            </html>
        '''
        
        results = self.checker.search_content("This is a test")
        self.assertTrue(len(results) > 0)