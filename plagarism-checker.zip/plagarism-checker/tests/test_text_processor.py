import unittest
from app.utils.text_processor import TextProcessor

class TestTextProcessor(unittest.TestCase):
    def test_split_into_sentences(self):
        text = "This is a test. This is another test."
        sentences = TextProcessor.split_into_sentences(text)
        
        self.assertEqual(len(sentences), 2)
        self.assertEqual(sentences[0], "This is a test.")
        self.assertEqual(sentences[1], "This is another test.")