from flask import Flask, request, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os
import threading
import time
from app.config import Config
from app.utils.file_handler import FileHandler
from app.utils.text_processor import TextProcessor
from app.utils.plagiarism_checker import PlagiarismChecker

app = Flask(__name__, static_folder='../static')
limiter = Limiter(app, key_func=get_remote_address)

# Ensure the upload folder exists
if not os.path.exists(Config.UPLOAD_FOLDER):
    os.makedirs(Config.UPLOAD_FOLDER, mode=0o775)

# Background thread to delete old files
def delete_old_files():
    while True:
        current_time = time.time()
        for filename in os.listdir(Config.UPLOAD_FOLDER):
            file_path = os.path.join(Config.UPLOAD_FOLDER, filename)
            if os.path.isfile(file_path) and \
               current_time - os.path.getmtime(file_path) > Config.DELETE_INTERVAL:
                os.remove(file_path)
        time.sleep(Config.DELETE_INTERVAL)

threading.Thread(target=delete_old_files, daemon=True).start()

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route("/api/upload", methods=["POST"])
async def upload():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400

        file = request.files["file"]
        filepath = FileHandler.save_file(file)

        if not filepath:
            return jsonify({"error": "Invalid file"}), 400

        # Extract text from the uploaded file
        text = TextProcessor.extract_text_from_pdf(filepath)
        if not text:
            return jsonify({"error": "Could not extract text from PDF"}), 400

        # Process the text and get significant sentences
        sentences = TextProcessor.extract_significant_content(text)
        if not sentences:
            return jsonify({"error": "No significant content found"}), 400

        # Check for plagiarism using check_content
        checker = PlagiarismChecker()
        results = await checker.check_content(sentences)

        # Validate results before sending
        results = validate_results(results)

        if not results:
            return jsonify({"error": "No matches found for the provided content"}), 200

        return jsonify({"success": True, "results": results}), 200

    except Exception as e:
        print(f"Error in upload endpoint: {str(e)}")
        return jsonify({"error": "An internal error occurred", "details": str(e)}), 500

    finally:
        # Optional cleanup, e.g., delete the uploaded file
        if filepath and os.path.exists(filepath):
            os.remove(filepath)
def validate_results(results):
    validated_results = []
    for result in results:
        if (
            isinstance(result, dict)
            and "sentence" in result
            and "source" in result
            and "similarity" in result
        ):
            validated_results.append(result)
    return validated_results

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
