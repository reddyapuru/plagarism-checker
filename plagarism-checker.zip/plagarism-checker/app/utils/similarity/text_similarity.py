from difflib import SequenceMatcher
import re

class TextSimilarity:
    @staticmethod
    def clean_text(text):
        """Clean text for comparison"""
        # Remove special characters and extra spaces
        text = re.sub(r'[^\w\s]', '', text.lower())
        return ' '.join(text.split())

    @staticmethod
    def calculate_similarity(text1, text2):
        """Calculate similarity ratio between two texts"""
        if not text1 or not text2:
            return 0.0
            
        # Clean texts
        clean_text1 = TextSimilarity.clean_text(text1)
        clean_text2 = TextSimilarity.clean_text(text2)
        
        # Calculate similarity
        return SequenceMatcher(None, clean_text1, clean_text2).ratio()