from PyPDF2 import PdfReader
import nltk
from nltk.tokenize import sent_tokenize
import re

nltk.download('punkt', quiet=True)
nltk.download('averaged_perceptron_tagger', quiet=True)

class TextProcessor:
    @staticmethod
    def clean_text(text):
        """Clean and normalize text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep punctuation
        text = re.sub(r'[^\w\s.,!?-]', '', text)
        return text.strip()

    @staticmethod
    def extract_text_from_pdf(filepath):
        """Extract and clean text from PDF"""
        reader = PdfReader(filepath)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + " "
        return TextProcessor.clean_text(text)

    @staticmethod
    def split_into_sentences(text):
        """Split text into meaningful sentences"""
        # Split into sentences
        sentences = sent_tokenize(text)
        
        # Filter and clean sentences
        valid_sentences = []
        for sentence in sentences:
            cleaned = TextProcessor.clean_text(sentence)
            # Only include sentences with sufficient content
            if len(cleaned.split()) >= 5 and len(cleaned) >= 20:
                valid_sentences.append(cleaned)
        
        return valid_sentences

    @staticmethod
    def extract_significant_content(text, max_sentences=10):
        """Extract most significant sentences for plagiarism checking"""
        sentences = TextProcessor.split_into_sentences(text)
        
        # Sort sentences by length and complexity
        scored_sentences = []
        for sentence in sentences:
            words = sentence.split()
            # Score based on length and word complexity
            score = len(words) + sum(len(word) > 6 for word in words)
            scored_sentences.append((score, sentence))
        
        # Get top sentences
        scored_sentences.sort(reverse=True)
        return [s[1] for s in scored_sentences[:max_sentences]]