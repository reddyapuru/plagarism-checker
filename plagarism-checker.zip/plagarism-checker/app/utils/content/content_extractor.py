import requests
from bs4 import BeautifulSoup
import trafilatura
from urllib.parse import urlparse

class ContentExtractor:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

    def extract_from_url(self, url):
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            if response.status_code != 200:
                return None

            # Try trafilatura first for better content extraction
            content = trafilatura.extract(response.text)
            if content:
                return self._clean_content(content)

            # Fallback to BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove unwanted elements
            for element in soup(['script', 'style', 'nav', 'header', 'footer']):
                element.decompose()

            # Extract text from article or main content
            main_content = soup.find('article') or soup.find('main') or soup.find('body')
            if main_content:
                return self._clean_content(' '.join(main_content.stripped_strings))
            
            return None

        except Exception as e:
            print(f"Error extracting content from {url}: {str(e)}")
            return None

    def _clean_content(self, content):
        if not content:
            return None
        # Remove extra whitespace
        content = ' '.join(content.split())
        return content if len(content) > 100 else None