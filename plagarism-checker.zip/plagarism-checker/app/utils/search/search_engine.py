from abc import ABC, abstractmethod
import requests
from bs4 import BeautifulSoup
import time

class SearchEngine(ABC):
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        self.session = requests.Session()
        self.rate_limit_delay = 2  # seconds between requests

    @abstractmethod
    def search(self, query):
        pass

    def _make_request(self, url, timeout=15):
        try:
            response = self.session.get(url, headers=self.headers, timeout=timeout)
            if response.status_code == 429:  # Rate limit
                time.sleep(60)
                return None
            return response
        except Exception as e:
            print(f"Search request failed: {str(e)}")
            return None