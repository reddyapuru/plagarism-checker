from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from .search_engine import SearchEngine

class GoogleSearch(SearchEngine):
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.google.com/search?q="

    async def search(self, query):
        # Construct the search URL with the query
        search_url = self.base_url + quote_plus(f'"{query}"')
        response = self._make_request(search_url)  # Make the request to Google
        
        if not response:
            return []

        results = []
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Parse the search results from the HTML response
        for result in soup.find_all("div", class_="g"):
            try:
                link = result.find("a")
                if not link:
                    continue
                    
                url = link.get("href", "")
                if not url.startswith("http"):
                    continue
                    
                title = result.find("h3")
                title = title.text if title else url
                
                snippet = result.find("div", class_="VwiC3b")
                snippet = snippet.text if snippet else ""
                
                # Append the result to the list
                results.append({
                    "url": url,
                    "title": title,
                    "snippet": snippet
                })
            except Exception as e:
                print(f"Error parsing Google result: {str(e)}")
                continue
                
        return results
