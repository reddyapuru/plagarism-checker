from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from .search_engine import SearchEngine

class ScholarSearch(SearchEngine):
    def __init__(self):
        super().__init__()
        self.base_url = "https://scholar.google.com/scholar?q="

    async def search(self, query):
        search_url = self.base_url + quote_plus(f'"{query}"')
        response = self._make_request(search_url)
        
        if not response:
            return []

        results = []
        soup = BeautifulSoup(response.text, "html.parser")
        
        for result in soup.select(".gs_ri"):
            try:
                title_elem = result.select_one(".gs_rt a")
                if not title_elem:
                    continue
                    
                url = title_elem.get("href", "")
                if not url.startswith("http"):
                    continue
                    
                title = title_elem.text
                
                snippet = result.select_one(".gs_rs")
                snippet = snippet.text if snippet else ""
                
                source = result.select_one(".gs_a")
                source = source.text if source else ""
                
                results.append({
                    "url": url,
                    "title": title,
                    "snippet": snippet,
                    "source": source
                })
            except Exception as e:
                print(f"Error parsing Scholar result: {str(e)}")
                continue
                
        return results
