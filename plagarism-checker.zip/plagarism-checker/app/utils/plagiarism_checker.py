import asyncio
from typing import List, Dict
from .search.google_search import GoogleSearch
from .search.scholar_search import ScholarSearch
from .content.content_extractor import ContentExtractor
from .similarity.text_similarity import TextSimilarity

class PlagiarismChecker:
    def __init__(self):
        # Initialize search engines, content extractor, and similarity checker
        self.search_engines = [
            GoogleSearch(),
            ScholarSearch()
        ]
        self.content_extractor = ContentExtractor()

    async def check_sentence(self, sentence: str) -> List[Dict]:
        """Check a single sentence for plagiarism"""
        if len(sentence.split()) < 5:  # Skip very short sentences
            return []

        results = []
        tasks = []  # List to store async search tasks

        # Collect async search tasks for each search engine
        for engine in self.search_engines:
            try:
                tasks.append(engine.search(sentence))  # Append async task for each engine
            except Exception as e:
                print(f"Error processing engine {engine.__class__.__name__}: {e}")

        # Gather all search results asynchronously
        search_results = await asyncio.gather(*tasks)  # Run all tasks concurrently

        # Process each result from the search engines
        for result_list in search_results:
            for result in result_list:
                content = await self.content_extractor.extract_from_url(result['url'])
                if not content:
                    continue

                # Calculate similarity between the sentence and the extracted content
                similarity = TextSimilarity.calculate_similarity(sentence, content)
                if similarity > 0.3:  # Include only significant matches
                    results.append({
                        "sentence": sentence,
                        "source": result['url'],
                        "sourceName": result.get('title', result['url'])[:100],
                        "similarity": round(similarity * 100),
                        "snippet": result.get('snippet', '')
                    })
            await asyncio.sleep(2)  # Respect rate limits

        # Return top 3 results sorted by similarity
        return sorted(results, key=lambda x: x['similarity'], reverse=True)[:3]

# Function to validate the results
def validate_results(results: List[Dict]) -> List[Dict]:
    """Ensure results are valid JSON"""
    validated_results = []
    for result in results:
        if (
            isinstance(result, dict)
            and "sentence" in result
            and "source" in result
            and "similarity" in result
        ):
            validated_results.append(result)
    return validated_results
