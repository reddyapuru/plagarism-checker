class Config:
    UPLOAD_FOLDER = '/tmp/uploads'
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5MB
    ALLOWED_EXTENSIONS = {'pdf'}
    DELETE_INTERVAL = 3600  # 1 hour in seconds
    MAX_SENTENCES = 10
    RATE_LIMIT = 60  # requests per minute