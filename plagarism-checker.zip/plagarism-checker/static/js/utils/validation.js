class FileValidator {
    static validateFile(file) {
        if (!file) {
            throw new Error('No file selected');
        }

        if (!CONFIG.ALLOWED_FILE_TYPES.includes(file.type)) {
            throw new Error('Invalid file type. Please upload a PDF file.');
        }

        if (file.size > CONFIG.MAX_FILE_SIZE) {
            throw new Error('File size exceeds 5MB limit');
        }

        return true;
    }
}

class ResponseValidator {
    static async validateResponse(response) {
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }
        return response.json();
    }
}