class FileHandler {
    constructor(dropZone, fileInput) {
        this.dropZone = dropZone;
        this.fileInput = fileInput;
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.dropZone.addEventListener('dragover', this.handleDragOver.bind(this));
        this.dropZone.addEventListener('dragleave', this.handleDragLeave.bind(this));
        this.dropZone.addEventListener('drop', this.handleDrop.bind(this));
    }

    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        this.dropZone.classList.add('drag-over');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        this.dropZone.classList.remove('drag-over');
    }

    handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        this.dropZone.classList.remove('drag-over');

        const file = e.dataTransfer.files[0];
        if (FileValidator.validateFile(file)) {
            this.fileInput.files = e.dataTransfer.files;
        }
    }
}