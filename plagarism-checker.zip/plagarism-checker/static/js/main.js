// Constants
const CONFIG = {
    UPLOAD_ENDPOINT: '/api/upload',
    MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_FILE_TYPES: ['application/pdf']
};

class PlagiarismChecker {
    constructor() {
        this.uploadForm = document.getElementById('uploadForm');
        this.dropZone = document.getElementById('dropZone');
        this.fileInput = document.getElementById('fileInput');
        this.progressElement = document.getElementById('progress');
        this.progressFillElement = document.getElementById('progressFill');
        this.resultsContainer = document.getElementById('results');

        this.fileHandler = new FileHandler(this.dropZone, this.fileInput);
        this.progressBar = new ProgressBar(this.progressElement, this.progressFillElement);
        this.resultsDisplay = new ResultsDisplay(this.resultsContainer);

        this.setupEventListeners();
    }

    setupEventListeners() {
        this.uploadForm.addEventListener('submit', this.handleSubmit.bind(this));
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const file = this.fileInput.files[0];
        if (!file) {
            this.resultsDisplay.showError('Please select a file');
            return;
        }

        try {
            FileValidator.validateFile(file);
            
            this.progressBar.show();
            this.progressBar.setProgress(0);
            this.resultsDisplay.showMessage('Analyzing document...');

            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch(CONFIG.UPLOAD_ENDPOINT, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Upload failed');
            }

            const data = await response.json();
            this.progressBar.setProgress(100);
            this.resultsDisplay.displayResults(data);

        } catch (error) {
            this.progressBar.hide();
            this.resultsDisplay.showError(error.message);
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new PlagiarismChecker();
});