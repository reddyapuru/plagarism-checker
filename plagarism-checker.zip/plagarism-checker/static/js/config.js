const CONFIG = {
    API_ENDPOINT: '/api',
    MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_FILE_TYPES: ['application/pdf'],
    UPLOAD_ENDPOINT: '/upload',
    CHECK_STATUS_ENDPOINT: '/status',
    POLLING_INTERVAL: 2000, // 2 seconds
};