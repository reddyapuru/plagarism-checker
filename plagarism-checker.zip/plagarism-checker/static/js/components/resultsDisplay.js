class ResultsDisplay {
    constructor(resultsContainer) {
        this.container = resultsContainer;
    }

    displayResults(data) {
        this.container.innerHTML = '';
        
        if (!data.results || data.results.length === 0) {
            this.showMessage('No plagiarism detected in the analyzed content.');
            return;
        }

        // Add summary
        const summary = document.createElement('div');
        summary.className = 'summary-section mb-6';
        summary.innerHTML = `
            <h2 class="text-xl font-semibold mb-2">Analysis Summary</h2>
            <p>Analyzed ${data.totalSentences} sentences and found ${data.matchesFound} potential matches.</p>
        `;
        this.container.appendChild(summary);
        
        // Add results
        data.results.forEach((result, index) => {
            const resultElement = this.createResultElement(result, index);
            this.container.appendChild(resultElement);
        });
    }

    createResultElement(result, index) {
        const element = document.createElement('div');
        element.className = 'result-item mb-6 p-4 border rounded-lg shadow-sm';
        
        const similarityClass = this.getSimilarityClass(result.similarity);
        const similarityText = this.getSimilarityText(result.similarity);

        element.innerHTML = `
            <div class="flex justify-between items-start mb-3">
                <div class="flex items-center">
                    <span class="similarity-badge ${similarityClass} px-3 py-1 rounded-full text-sm font-medium">
                        ${result.similarity}% Match
                    </span>
                    <span class="ml-2 text-sm text-gray-500">${similarityText}</span>
                </div>
                <a href="${result.source}" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   class="text-blue-600 hover:text-blue-800 text-sm flex items-center">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                              d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                    </svg>
                    View Source
                </a>
            </div>
            <div class="matched-content mb-3">
                <div class="bg-gray-50 p-3 rounded border border-gray-200">
                    <h4 class="font-medium mb-2">Matched Text:</h4>
                    <p class="text-gray-700">${result.sentence}</p>
                </div>
                ${result.snippet ? `
                    <div class="mt-2 bg-gray-50 p-3 rounded border border-gray-200">
                        <h4 class="font-medium mb-2">Source Context:</h4>
                        <p class="text-gray-700">${result.snippet}</p>
                    </div>
                ` : ''}
            </div>
            <div class="source-info text-sm text-gray-500">
                <div class="flex items-center">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                              d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                    </svg>
                    Source: ${result.sourceName}
                </div>
            </div>
        `;

        return element;
    }

    getSimilarityClass(similarity) {
        if (similarity > 70) return 'bg-red-100 text-red-800';
        if (similarity > 40) return 'bg-yellow-100 text-yellow-800';
        return 'bg-green-100 text-green-800';
    }

    getSimilarityText(similarity) {
        if (similarity > 70) return 'High similarity - potential plagiarism';
        if (similarity > 40) return 'Moderate similarity - needs review';
        return 'Low similarity - likely original';
    }

    showMessage(message) {
        this.container.innerHTML = `
            <div class="text-center p-6">
                <p class="text-gray-600">${message}</p>
            </div>
        `;
    }

    showError(message) {
        this.container.innerHTML = `
            <div class="error-message bg-red-50 border-l-4 border-red-500 p-4">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" 
                                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" 
                                  clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-700">${message}</p>
                    </div>
                </div>
            </div>
        `;
    }
}