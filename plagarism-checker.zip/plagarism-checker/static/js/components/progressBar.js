class ProgressBar {
    constructor(progressElement, progressFillElement) {
        this.progressElement = progressElement;
        this.progressFillElement = progressFillElement;
        this.statusText = progressElement.querySelector('.progress-text');
    }

    show() {
        this.progressElement.classList.remove('hidden');
    }

    hide() {
        this.progressElement.classList.add('hidden');
    }

    setProgress(percent, status = '') {
        this.progressFillElement.style.width = `${percent}%`;
        if (status) {
            this.setStatus(status);
        }
    }

    setStatus(status) {
        if (this.statusText) {
            this.statusText.textContent = status;
        }
    }
}